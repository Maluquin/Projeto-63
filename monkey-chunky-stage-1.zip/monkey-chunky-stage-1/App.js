import * as React from 'react';
import { Text, View, StyleSheet, TextInput, TouchableOpacity, Image } from 'react-native';
import {Header} from 'react-native-elements';
import {SafeAreaProvider} from 'react-native-safe-area-context';
import db from './localdb';
import PhonicSoundButton from './components/PhonicSoundButton'

//console.log(db["teens"].chunks)

export default class App extends React.Component {
  constructor(){
    super();
    this.state={
      texto: '',
      chunks: [],
      phones: []
    }
  }
  render() {
    return (
      <SafeAreaProvider>
        <View style={styles.container}>
          <Header
            backgroundColor={'lightgreen'}
            centerComponent={{
              text: 'Monkey Chunky',
              
              style:{fontSize: 20, fontWeight:'bold'}
            }}
          />

          <Image
            style={styles.image}
            source ={{
              uri: 'https://imagensemoldes.com.br/wp-content/uploads/2020/05/Desenho-Macaco-PNG.png'
            }}
          />

          <TextInput 
            style={styles.input}
            onChangeText={textoDigitado => {
              this.setState({texto: textoDigitado})
            }}
            value={this.state.texto}
          />

          <TouchableOpacity onPress={()=>{
            this.setState({chunks:db[this.state.texto].chunks})
            this.setState({phones:db[this.state.texto].phones})
          }}
          
          style={styles.button}
          >

          
          
            <Text>MOSTRAR</Text>
          </TouchableOpacity>

          <View>
            {this.state.chunks.map((item, index)=>{
              return(
               <PhonicSoundButton
                wordChunk = {this.state.chunks[index]}
                soundChunk = {this.state.phones[index]}

               />
              )

            })}


          </View>
        </View>
      </SafeAreaProvider>
    );
  }
}

const styles = StyleSheet.create({
 container: {
    flex: 1,
    backgroundColor: '#febd84',
  },
  input: {
    borderWidth: 2,
    borderRadius: 15,
    width: '70%',
    height: 30,
    alignSelf: 'center',
    textAlign: 'center'
},
button:{
  alignSelf: 'center',
  margin: 10,
  width: 70,
  height: 20,
  backgroundColor: 'lightGreen'

},
image: {
  width: 150,
  height: 150,
  alignSelf: 'center'
}


});
