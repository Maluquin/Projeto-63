 import * as React from 'react';
 import {Text, TouchableOpacity, StyleSheet} from 'react-native';
 import {Audio} from 'expo-av';

 export default class PhonicSoundButton extends React.Component{

   playSound = async (soundChunk) => {
     var soundLink = 'https://s3-whitehatjrcontent.whjr.online/phones/' + soundChunk + '.mp3';

     await Audio.Sound.createAsync(
       {uri: soundLink},
       {shouldPlay: true},
     )
   }



   render(){
     return(
       
      <TouchableOpacity style={styles.buttonChunk}
          onPress={()=> {this.playSound(this.props.soundChunk)}}>
          <Text style={styles.buttonChunkText}>{this.props.wordChunk}</Text>
      </TouchableOpacity>
    )
       
    
   }
 }
 

 const styles = StyleSheet.create({
   buttonChunk: {
    width: '60%',
    height: 50,
    backgroundColor: 'lightblue',
    alignItems: 'center',
    alignSelf: 'center',
    marginTop: 10,
    justifyContent: 'center',
    borderRadius: 15
},
  buttonChunkText:{
  fontSize: 20,
  fontWeight: 800,
  fontFamily: 'monospace'
  
}
 })

 
    